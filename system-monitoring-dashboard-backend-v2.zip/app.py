from flask import Flask
from routes.metrics_routes import metrics_bp

app = Flask(__name__)
app.register_blueprint(metrics_bp)

@app.route("/health")
def health():
    return {"status": "running"}

if __name__ == "__main__":
    app.run(debug=True)
