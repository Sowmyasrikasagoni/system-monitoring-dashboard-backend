# TODO: JWT authentication logic
