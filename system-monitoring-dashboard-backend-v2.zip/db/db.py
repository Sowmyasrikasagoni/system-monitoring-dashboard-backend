# TODO: SQLite connection and insert logic
