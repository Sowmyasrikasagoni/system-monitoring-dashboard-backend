# System Monitoring Dashboard (Backend)

## Overview
Backend system monitoring service exposing system metrics via REST APIs.
This repository is an **active work-in-progress (WIP)** project.

## Tech Stack
- Python
- Flask
- psutil
- SQLite
- JWT (planned)
- AWS-ready

## Current Features
- Health check API
- CPU, memory, disk metrics API
- Modular backend structure

## Planned Features
- JWT authentication
- Metrics persistence (SQLite)
- Role-based access
- AWS EC2 deployment

## Run Locally
pip install -r requirements.txt
python app.py
